from django.shortcuts import render
from django.http import HttpResponse
from .models import Employee,Managers

# Create your views here.
def home(request):
    return render(request,"home.html")

def contact(request):
    return render(request,"contact.html")

def about(request):
    return render(request,"about.html")

def emplist(request):
   records=Employee.objects.all()
   return render(request,'empdetails.html',
                 {'records':records,
                  'count':len(records)
                  }
                )

def managers(request):
    records=Managers.objects.all()
    return render(request,'managers.html',
                  {'records':records,})