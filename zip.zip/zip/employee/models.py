from django.db import models

# Create your models here.
class Employee(models.Model):
    name=models.CharField(max_length=30)
    desg=models.CharField(max_length=50)
    salary=models.FloatField(default=25000)

    def __str__(self):
        return self.name+" "+self.desg
    
class Managers(models.Model):
    name=models.CharField(max_length=30)
    TeamName=models.CharField(max_length=30)
    salary=models.FloatField(default=50000)
    ReporteeCounts=models.FloatField(default=5)

    def __str__(self):
        return self.name+" "+self.TeamName
